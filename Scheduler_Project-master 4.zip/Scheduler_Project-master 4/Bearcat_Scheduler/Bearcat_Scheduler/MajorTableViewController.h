//
//  MajorTableViewController.h
//  Bearcat_Scheduler
//
//  Created by Smith,Logan W on 4/4/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MajorTableViewController : UITableViewController

@end

NS_ASSUME_NONNULL_END
