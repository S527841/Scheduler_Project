//
//  RegisterController.h
//  Bearcat_Scheduler
//
//  Created by Smith,Logan W on 3/12/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RegisterController : NSObject

@end

NS_ASSUME_NONNULL_END
